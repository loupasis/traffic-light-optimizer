
class Movement:
    def __init__(self, name, flow, width, n_lanes, flu, bus_stops=0, parking_maneuvers=0, p_hv=10, p_lt=0, p_rt=0):
        self.name = name                 
        self.flow = flow #  (V_raw / ΣΩΑ)
        self.width = width               
        self.n_lanes = n_lanes           
        self.flu = flu 
        self.bus_stops = bus_stops       
        self.parking_maneuvers = parking_maneuvers 
        self.p_hv = p_hv 
        self.p_lt = p_lt / 100.0 
        self.p_rt = p_rt / 100.0
        
        # Σταθερές
        self.s0 = 2100 
        self.fa = 0.90 
        self.saturation_flow = 0  
        self.y = 0