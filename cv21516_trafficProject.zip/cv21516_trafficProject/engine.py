
import math

def get_saturation_flow(mv):
   
    fw = 1 + (mv.width - 3.6) / 9.0 
    
    
    fhv = 100 / (100 + mv.p_hv * (2.0 - 1.0)) 
    
   
    fp = (mv.n_lanes - 0.1 - (18.0 * mv.parking_maneuvers / 3600.0)) / mv.n_lanes if mv.parking_maneuvers > 0 else 1.0
    

    fbb = (mv.n_lanes - (14.4 * mv.bus_stops / 3600.0)) / mv.n_lanes if mv.bus_stops > 0 else 1.0
    
    if mv.p_lt >= 1.0:
        flt = 0.95
    elif mv.p_lt > 0:
        flt = 1.0 / (1.0 + 0.05 * mv.p_lt)
    else:
        flt = 1.0
        

    if mv.p_rt >= 1.0:
        frt = 0.85
    elif mv.p_rt > 0:
        if mv.n_lanes == 1:
            frt = 1.0 - 0.135 * mv.p_rt
        else:
            frt = 1.0 - 0.15 * mv.p_rt
    else:
        frt = 1.0

    mv.saturation_flow = mv.s0 * mv.n_lanes * fw * fhv * fp * fbb * mv.fa * mv.flu * flt * frt
    mv.y = mv.flow / mv.saturation_flow if mv.saturation_flow > 0 else 0
    return mv.saturation_flow

def get_los_grade(delay):

    if delay <= 10.0: return "A"
    elif delay <= 20.0: return "B"
    elif delay <= 35.0: return "C"
    elif delay <= 56.0: return "D"
    elif delay <= 80.0: return "E"
    else: return "F"

def get_performance_metrics(v, s, g, C):
    if g <= 0 or C <= 0 or s <= 0: return 999.0, "F"
    
    c_cap = s * (g / C) 
    X = v / (c_cap if c_cap > 0 else 0.001)
    
    d1 = (0.5 * C * (1.0 - g/C)**2) / (1.0 - (min(1.0, X) * g/C))
    
    T = 0.25; A = 0.50; F = 1.0
    c_safe = max(0.1, c_cap)
    
    d2 = 900 * T * ((X - 1.0) + math.sqrt((X - 1.0)**2 + (8.0 * A * F * X) / (c_safe * T)))
    d_total = d1 + d2
    
    if X > 1.0: d_total = max(d_total, 180.0)
    
    grade = get_los_grade(d_total)
    return round(d_total, 2), grade