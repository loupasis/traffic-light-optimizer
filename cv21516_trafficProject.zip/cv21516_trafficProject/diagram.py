
import matplotlib.pyplot as plt

def draw_traffic_diagram(ga, gb, gg, cycle, l_val=2, a_val=3):
    ka = ga + l_val - a_val
    kb = gb + l_val - a_val
    kg = gg + l_val - a_val
    
    intergreen = 5 
    
    t1 = ka                   
    t2 = t1 + a_val           
    t3 = ka + intergreen      
    
    t4 = t3 + kb              
    t5 = t4 + a_val           
    t6 = t3 + kb + intergreen 
    
    t7 = t6 + kg              
    t8 = t7 + a_val           

    movements = {
        "Κ1/ευθ. (Α+Β)": [
            (0, t4, 'green'), 
          (t4, t5, 'yellow'), (t5, cycle, 'red')
        ],
        "Κ2 (Φάση Α)": [
            (0, t1, 'green'), (t1, t2, 'yellow'), (t2, cycle, 'red')
        ],
        "Κ1/αρ. (Φάση Β)": [
            (0, t3, 'red'), (t3, t4, 'green'), (t4, t5, 'yellow'), (t5, cycle, 'red')
        ],
        "Κ3 (Φάση Γ)": [
            (0, t6, 'red'), (t6, t7, 'green'), (t7, t8, 'yellow'), (t8, cycle, 'red')
        ]
    }

    fig, ax = plt.subplots(figsize=(12, 7))
    
    for i, (name, intervals) in enumerate(movements.items()):
        for start, end, color in intervals:
            duration = end - start
            ax.broken_barh([(start, duration)], (i*10, 8), facecolors=color, edgecolor='black')
            
            

    ax.set_ylim(-5, 45)
    ax.set_xlim(0, cycle)
    ax.set_xlabel('Χρόνος Κύκλου (δευτερόλεπτα)')
    ax.set_yticks([4, 14, 24, 34])
    ax.set_yticklabels(list(movements.keys()))
    ax.set_xticks(range(0, int(cycle)+1, 5))
    ax.grid(True, axis='x', linestyle='--', alpha=0.5)
    
    plt.title(f'Διάγραμμα Σηματοδότησης (C={cycle}s, ga={ga}, gb={gb}, gg={gg})')
    plt.tight_layout()
    plt.show()