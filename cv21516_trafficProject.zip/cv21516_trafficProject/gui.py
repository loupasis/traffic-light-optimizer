
import tkinter as tk
from tkinter import messagebox, filedialog
import json
import logic
from models import Movement
import diagram 

class TrafficGUI:
   

    def create_menu(self):
        menubar = tk.Menu(self.root)
        self.root.config(menu=menubar)
        help_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Help", menu=help_menu)
        help_menu.add_command(label="About", command=self.show_about)
    def __init__(self, root):
        self.root = root
        self.root.title("Traffic Study NTUA ")
        self.root.geometry("850x1000")
        self.last_results = None
        info_frame = tk.Frame(root, bg="#ecf0f1", pady=10)
        info_frame.pack(fill="x")
        
        self.work_info_text = (
            "Εργασία: Λουπάσης Θεόδωρος (cv21516)  Έτος: 2025-2026\n"
            "Βελτιστοποίηση Κυκλοφορίας Σηματοδοτούμενου Κόμβου"
        )
        
        info_btn = tk.Button(info_frame, text="Πληροφορίες Εργασίας", command=self.show_work_info,
                             bg="#ecf0f1", fg="#2c3e50", font=("Arial", 8), bd=0, relief="flat")
        info_btn.pack(side="right")

        container = tk.Frame(root, padx=20, pady=10)
        container.pack(expand=True, fill="both")

        # mpara arxeion
        file_frame = tk.Frame(container)
        file_frame.pack(fill="x", pady=(0, 10))
        
        tk.Button(file_frame, text=" Load .dat", command=self.load_from_file, bg="#34495e", fg="white", font=("Arial", 9, "bold")).pack(side="left", padx=5)
        tk.Button(file_frame, text=" Save .dat", command=self.save_to_file, bg="#34495e", fg="white", font=("Arial", 9, "bold")).pack(side="left", padx=5)
        tk.Button(file_frame, text=" Export .res", command=self.export_res, bg="#27ae60", fg="white", font=("Arial", 9, "bold")).pack(side="right", padx=5)

        # input dedomenwn
        self.inputs = {}
        configs = [
            ("Κ1 Ευθεία", [("V_thru", "Φόρτος Ευθείας:", "800"), ("PHF", "ΣΩΑ:", "0.95"), ("N", "Λωρίδες N:", "2"), ("W", "Πλάτος W:", ""), ("Nb", "Στάσεις Λεωφ./ώρα:", ""), ("Nm", "Ελιγμοί Στάθμ./ώρα:", ""), ("HV", "Βαρέα %HV:", "")]),
            ("Κ1 Αριστερά", [("V_left", "Φόρτος Αριστερά:", "200"), ("PHF", "ΣΩΑ:", "0.95"), ("N", "Λωρίδες N:", "1"), ("W", "Πλάτος W:", ""), ("Nm", "Ελιγμοί Στάθμ./ώρα:", ""), ("HV", "Βαρέα %HV:", "")]),
            ("Κ2 Ευθ+Δεξ", [("V_thru", "Φόρτος Ευθείας:", "700"), ("V_right", "Φόρτος Δεξιά:", "120"), ("PHF", "ΣΩΑ:", "0.95"), ("N", "Λωρίδες N:", "2"), ("W", "Πλάτος W:", ""), ("Nb", "Στάσεις Λεωφ./ώρα:", ""), ("Nm", "Ελιγμοί Στάθμ./ώρα:", ""), ("HV", "Βαρέα %HV:", "")]),
            ("Κ3 Μικτή", [("V_left", "Φόρτος Αριστερά:", "50"), ("V_thru", "Φόρτος Ευθείας:", "160"), ("V_right", "Φόρτος Δεξιά:", "100"), ("PHF", "ΣΩΑ:", "0.95"), ("N", "Λωρίδες N:", ""), ("W", "Πλάτος W:", ""), ("Nm", "Ελιγμοί Στάθμ./ώρα:", ""), ("HV", "Βαρέα %HV:", "")])
        ]

        for title, fields in configs:
            box = tk.LabelFrame(container, text=f" {title} ", font=("Arial", 9, "bold"))
            box.pack(fill="x", pady=4)
            ents = {}
            for i, (key, label_text, default_val) in enumerate(fields):
                r = i // 3; c = i % 3
                tk.Label(box, text=label_text).grid(row=r, column=c*2, sticky="w", padx=2, pady=2)
                e = tk.Entry(box, width=8); e.insert(0, default_val)
                e.grid(row=r, column=c*2+1, padx=5, pady=2)
                ents[key] = e
            self.inputs[title] = ents

        # parametroi mellontikhs provlpepsis
        fut_box = tk.LabelFrame(container, text=" Παράμετροι Μελλοντικής Πρόβλεψης ", font=("Arial", 9, "bold"), fg="#2980b9")
        fut_box.pack(fill="x", pady=5)
        tk.Label(fut_box, text="Έτη Πρόβλεψης (t):").grid(row=0, column=0, padx=5, pady=5, sticky="w")
        self.fut_years = tk.Entry(fut_box, width=6); self.fut_years.insert(0, "5")
        self.fut_years.grid(row=0, column=1, padx=5, pady=5)
        
        tk.Label(fut_box, text="Ετήσιος Ρυθμός Αύξησης (r %):").grid(row=0, column=2, padx=5, pady=5, sticky="w")
        self.fut_rate = tk.Entry(fut_box, width=6); self.fut_rate.insert(0, "1.1")
        self.fut_rate.grid(row=0, column=3, padx=5, pady=5)

        # pliktra xeirismou
        tk.Button(container, text="1. ΕΚΤΕΛΕΣΗ ΑΡΧΙΚΩΝ ΥΠΟΛΟΓΙΣΜΩΝ ", command=self.run, bg="#2c3e50", fg="white", pady=10, font=("Arial", 10, "bold")).pack(fill="x", pady=2)
        tk.Button(container, text="2. ΕΜΦΑΝΙΣΗ ΔΙΑΓΡΑΜΜΑΤΟΣ ΣΗΜΑΤΟΔΟΤΗΣΗΣ", command=self.show_diag, bg="#e67e22", fg="white", pady=8, font=("Arial", 10, "bold")).pack(fill="x", pady=2)
        tk.Button(container, text="3. ΜΕΛΛΟΝΤΙΚΗ ΑΞΙΟΛΟΓΗΣΗ ΜΕ ΣΤΑΘΕΡΟ ΚΥΚΛΟ ", command=self.run_future, bg="#2980b9", fg="white", pady=10, font=("Arial", 10, "bold")).pack(fill="x", pady=2)
        
        # perioxh me apotelesmata
        self.res = tk.Text(container, font=("Consolas", 9), bg="#ffffff", height=20)
        self.res.pack(fill="both", expand=True, pady=10)

    def save_to_file(self):
        data = {name: {k: e.get() for k, e in ents.items()} for name, ents in self.inputs.items()}
        filename = filedialog.asksaveasfilename(defaultextension=".dat", filetypes=[("Data files", "*.dat"), ("All files", "*.*")])
        if filename:
            with open(filename, 'w', encoding='utf-8') as f: json.dump(data, f, indent=4)
            messagebox.showinfo("Επιτυχία", f"Τα δεδομένα αποθηκεύτηκαν στο:\n{filename}")

    def load_from_file(self):
        filename = filedialog.askopenfilename(filetypes=[("Data files", "*.dat"), ("All files", "*.*")])
        if filename:
            try:
                with open(filename, 'r', encoding='utf-8') as f: data = json.load(f)
                for name, values in data.items():
                    if name in self.inputs:
                        for k, val in values.items():
                            if k in self.inputs[name]:
                                self.inputs[name][k].delete(0, tk.END); self.inputs[name][k].insert(0, val)
            except Exception as e: messagebox.showerror("Σφάλμα", f"Αποτυχία φόρτωσης αρχείου:\n{e}")

    def export_res(self):
        result_text = self.res.get(1.0, tk.END).strip()
        if not result_text:
            messagebox.showwarning("Προσοχή", "Δεν υπάρχουν αποτελέσματα για εξαγωγή.")
            return
        filename = filedialog.asksaveasfilename(defaultextension=".res", filetypes=[("Result files", "*.res"), ("Text files", "*.txt")])
        if filename:
            with open(filename, 'w', encoding='utf-8') as f: f.write(result_text)
            messagebox.showinfo("Επιτυχία", f"Η έκθεση αποθηκεύτηκε στο:\n{filename}")

    def validate_numeric_inputs(self):
        
        for frame_name, fields in self.inputs.items():
            for key, entry in fields.items():
                val = entry.get().strip()
                if val == "":
                    messagebox.showerror("Σφάλμα Εισαγωγής", f"Η τιμή για '{key}' στην κίνηση '{frame_name}' είναι κενή. Συμπληρώστε έναν αριθμό.")
                    return False
                try:
                    if key == "N":
                        int(val)
                    else:
                        float(val)
                except ValueError:
                    messagebox.showerror("Σφάλμα Εισαγωγής", f"ΣΦΑΛΜΑ: Το πεδίο '{key}' στην κίνηση '{frame_name}' πρέπει να είναι αριθμός!")
                    return False
                # Ειδικός έλεγχος για πλάτος λωρίδας
                if key == "W":
                    try:
                        w_val = float(val)
                        if w_val < 3.0 or w_val > 4.0:
                            messagebox.showerror("Σφάλμα Εισαγωγής", f"ΒΑΛΕ ΑΠΟΔΕΚΤΟ ΠΛΑΤΟΣ ΛΩΡΙΔΑΣ (3 έως 4)\n\nΤο σφάλμα βρέθηκε στην κίνηση: {frame_name}")
                            return False
                    except ValueError:
                        messagebox.showerror("Σφάλμα Εισαγωγής", f"ΣΦΑΛΜΑ: Το πλάτος W στην κίνηση '{frame_name}' πρέπει να είναι αριθμός!")
                        return False

        
        try:
            if self.fut_years.get().strip() == "":
                messagebox.showerror("Σφάλμα Εισαγωγής", "Συμπληρώστε τα 'Έτη Πρόβλεψης (t)'.")
                return False
            float(self.fut_years.get())
        except ValueError:
            messagebox.showerror("Σφάλμα Εισαγωγής", "Το πεδίο 'Έτη Πρόβλεψης (t)' πρέπει να είναι αριθμός!")
            return False

        try:
            if self.fut_rate.get().strip() == "":
                messagebox.showerror("Σφάλμα Εισαγωγής", "Συμπληρώστε τον 'Ετήσιο Ρυθμό Αύξησης (r %)'.")
                return False
            float(self.fut_rate.get())
        except ValueError:
            messagebox.showerror("Σφάλμα Εισαγωγής", "Το πεδίο 'Ετήσιος Ρυθμός Αύξησης (r %)' πρέπει να είναι αριθμός!")
            return False

        return True

    def gather_movements(self, growth_factor=1.0):
        mvs = {}
        # Κ1 Ευθεία
        d = self.inputs["Κ1 Ευθεία"]
        v_thru_adj = round((float(d["V_thru"].get()) / float(d["PHF"].get())) * growth_factor)
        n = int(d["N"].get()); flu = v_thru_adj / (v_thru_adj * n) if v_thru_adj > 0 else 1.0
        mvs["Κ1 Ευθεία"] = Movement("Κ1 Ευθεία", v_thru_adj, float(d["W"].get()), n, flu, float(d["Nb"].get()), float(d["Nm"].get()), float(d["HV"].get()), 0, 0)
        
        # Κ1 Αριστερά
        d = self.inputs["Κ1 Αριστερά"]
        v_left_adj = round((float(d["V_left"].get()) / float(d["PHF"].get())) * growth_factor)
        n = int(d["N"].get()); flu = v_left_adj / (v_left_adj * n) if v_left_adj > 0 else 1.0
        mvs["Κ1 Αριστερά"] = Movement("Κ1 Αριστερά", v_left_adj, float(d["W"].get()), n, flu, 0, float(d["Nm"].get()), float(d["HV"].get()), 100, 0)
        
        # Κ2 Ευθ+Δεξ
        d = self.inputs["Κ2 Ευθ+Δεξ"]
        v_thru_adj = round(float(d["V_thru"].get()) / float(d["PHF"].get()))
        v_right_adj = round(float(d["V_right"].get()) / float(d["PHF"].get()))
        flow = round((v_thru_adj + v_right_adj) * growth_factor)
        n = int(d["N"].get()); flu = flow / ((v_thru_adj * growth_factor) * n) if v_thru_adj > 0 else 1.0
        p_rt = (v_right_adj / (v_thru_adj + v_right_adj)) * 100.0 if (v_thru_adj + v_right_adj) > 0 else 0
        mvs["Κ2 Ευθ+Δεξ"] = Movement("Κ2 Ευθ+Δεξ", flow, float(d["W"].get()), n, flu, float(d["Nb"].get()), float(d["Nm"].get()), float(d["HV"].get()), 0, p_rt)
        
        # Κ3 Μικτή
        d = self.inputs["Κ3 Μικτή"]
        v_left_adj = round(float(d["V_left"].get()) / float(d["PHF"].get()))
        v_thru_adj = round(float(d["V_thru"].get()) / float(d["PHF"].get()))
        v_right_adj = round(float(d["V_right"].get()) / float(d["PHF"].get()))
        base_sum = v_left_adj + v_thru_adj + v_right_adj
        flow = round(base_sum * growth_factor)
        n = int(d["N"].get()); flu = flow / ((v_thru_adj * growth_factor) * n) if v_thru_adj > 0 else 1.0
        p_lt = (v_left_adj / base_sum) * 100.0 if base_sum > 0 else 0
        p_rt = (v_right_adj / base_sum) * 100.0 if base_sum > 0 else 0
        mvs["Κ3 Μικτή"] = Movement("Κ3 Μικτή", flow, float(d["W"].get()), n, flu, 0, float(d["Nm"].get()), float(d["HV"].get()), p_lt, p_rt)
        
        return mvs

    def show_work_info(self):
        messagebox.showinfo("Πληροφορίες Εργασίας", self.work_info_text)

    def run(self):
        if not self.validate_numeric_inputs():
            return

        try:
            mvs = self.gather_movements(growth_factor=1.0)
            mv_res, app_res, d_node, node_los, final_c, final_x, crit_label = logic.run_intersection_logic(mvs)
            self.last_results = (mv_res["Κ2 Ευθ+Δεξ"]["g"], mv_res["Κ1 Αριστερά"]["g"], mv_res["Κ3 Μικτή"]["g"], final_c)

            report = f"ΑΝΑΛΥΣΗ ΚΡΙΣΙΜΗΣ ΔΙΑΔΡΟΜΗΣ & ΣΤΑΘΜΗΣ ΕΞΥΠΗΡΕΤΗΣΗΣ (ΕΤΟΣ 0)\n{'='*80}\n"
            report += f"Κρίσιμο Μονοπάτι: {crit_label}\nΕπιλέχθηκε Κύκλος C = {final_c}s (X_cr = {final_x:.3f})\n{'='*80}\n\n"
            report += " ΣΤΑΘΜΗ ΕΞΥΠΗΡΕΤΗΣΗΣ ΑΝΑ ΟΜΑΔΑ ΚΙΝΗΣΕΩΝ\n"
            report += f"{'-'*80}\n{'Ομάδα Κίνησης':18} | {'v':>5} | {'s':>5} | {'y (v/s)':>8} | {'d (s)':>6} | {'LOS':>3}\n{'-'*80}\n"
            for name, r in mv_res.items():
                report += f"{name:18} | {int(r['v']):>5} | {r['s']:>5} | {r['y']:>8.5f} | {r['d']:>6.2f} | {r['los']:>3}\n"
            report += "\n ΣΤΑΘΜΗ ΕΞΥΠΗΡΕΤΗΣΗΣ ΑΝΑ ΠΡΟΣΒΑΣΗ\n"
            report += f"{'-'*80}\n{'Πρόσβαση':18} | {'d_πρόσβασης (s)':>18} | {'LOS':>5}\n{'-'*70}\n"
            for r in app_res: report += f"{r['name']:18} | {r['d']:18.2f} | {r['los']:>5}\n"
            report += f"{'='*80}\nΜΕΣΗ ΚΑΘΥΣΤΕΡΗΣΗ ΚΟΜΒΟΥ: {d_node:.2f} s\nΣΤΑΘΜΗ ΕΞΥΠΗΡΕΤΗΣΗΣ ΚΟΜΒΟΥ: {node_los}\n"
            
            self.res.delete(1.0, tk.END); self.res.insert(tk.END, report)
        except Exception as e: messagebox.showerror("Σφάλμα", f"Πρόβλημα: {e}")

    def run_future(self):
        if not self.last_results:
            messagebox.showwarning("Προσοχή", "Πρέπει πρώτα να εκτελέσετε τους Αρχικούς Υπολογισμούς (Κουμπί 1)!")
            return
        if not self.validate_numeric_inputs():
            return
        try:
            ga, gb, gg, final_c = self.last_results
            t = float(self.fut_years.get())
            r = float(self.fut_rate.get())
            
            growth_factor = (1.0 + (r / 100.0)) ** t
            mvs_future = self.gather_movements(growth_factor=growth_factor)
            
            mv_res, app_res, d_node, node_los = logic.run_fixed_signal_analysis(mvs_future, final_c, ga, gb, gg)
            
            report = f"ΜΕΛΛΟΝΤΙΚΗ ΑΞΙΟΛΟΓΗΣΗ ΚΟΜΒΟΥ ΜΕΤΑ ΑΠΟ {int(t)} ΕΤΗ (Ρυθμός Αύξησης: {r}%)\n"
            report += f"s Διατήρηση Σταθερού Φαναριού: Κύκλος C = {final_c}s | gA={ga}s | gB={gb}s | gΓ={gg}s\n"
            report += f"{'='*80}\n\n"
            report += " ΜΕΛΛΟΝΤΙΚΗ ΣΤΑΘΜΗ ΕΞΥΠΗΡΕΤΗΣΗΣ ΑΝΑ ΟΜΑΔΑ ΚΙΝΗΣΕΩΝ\n"
            report += f"{'-'*80}\n{'Ομάδα Κίνησης':18} | {'v\'':>5} | {'s':>5} | {'y (v/s)':>8} | {'d (s)':>6} | {'LOS':>3}\n{'-'*80}\n"
            for name, r_data in mv_res.items():
                report += f"{name:18} | {int(r_data['v']):>5} | {r_data['s']:>5} | {r_data['y']:>8.5f} | {r_data['d']:>6.2f} | {r_data['los']:>3}\n"
            report += "\n ΜΕΛΛΟΝΤΙΚΗ ΣΤΑΘΜΗ ΕΞΥΠΗΡΕΤΗΣΗΣ ΑΝΑ ΠΡΟΣΒΑΣΗ\n"
            report += f"{'-'*80}\n{'Πρόσβαση':18} | {'d_πρόσβασης (s)':>18} | {'LOS':>5}\n{'-'*70}\n"
            for r_data in app_res: report += f"{r_data['name']:18} | {r_data['d']:18.2f} | {r_data['los']:>5}\n"
            report += f"{'='*80}\nΜΕΣΗ ΜΕΛΛΟΝΤΙΚΗ ΚΑΘΥΣΤΕΡΗΣΗ ΚΟΜΒΟΥ: {d_node:.2f} s\nΜΕΛΛΟΝΤΙΚΗ ΣΤΑΘΜΗ ΕΞΥΠΗΡΕΤΗΣΗΣ ΚΟΜΒΟΥ: {node_los}\n"
            
            self.res.delete(1.0, tk.END); self.res.insert(tk.END, report)
        except Exception as e: messagebox.showerror("Σφάλμα", f"Πρόβλημα: {e}")

    def show_diag(self):
        if self.last_results: diagram.draw_traffic_diagram(*self.last_results)
        else: messagebox.showwarning("Προσοχή", "Εκτελέστε πρώτα τους υπολογισμούς!")

def start_app():
    root = tk.Tk(); app = TrafficGUI(root); root.mainloop()