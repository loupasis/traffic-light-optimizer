import numpy as np
import matplotlib.pyplot as plt


years_past = np.array([2016, 2017, 2018, 2019, 2020, 2021, 2022, 2023, 2024, 2025])
traffic_volumes = np.array([650, 670, 690, 715, 680, 680, 755, 750, 780, 800])

# Quadratic Fit

a, b, c = np.polyfit(years_past, traffic_volumes, 2)


years_future = np.array([2026, 2027, 2028, 2029, 2030])
predicted_volumes = a * (years_future**2) + b * years_future + c

plt.figure(figsize=(10, 6))

plt.scatter(years_past, traffic_volumes, color='blue', label='Ιστορικά Δεδομένα', zorder=5)


plt.plot(years_past, a * (years_past**2) + b * years_past + c, color='gray', linestyle='--', label='Μοντέλο (2nd Degree Fit)')


plt.plot(years_future, predicted_volumes, color='red', marker='o', label='Πρόβλεψη Μοντέλου (Forecasting)')


plt.title('Πρόβλεψη Κυκλοφοριακού Φόρτου (Πολυωνυμική 2ου Βαθμού)')
plt.xlabel('Έτος')
plt.ylabel('Φόρτος (Οχήματα / ώρα)')
plt.grid(True, linestyle=':', alpha=0.7)
plt.legend()


plt.show()


v_start = a * (2025**2) + b * 2025 + c
v_end = predicted_volumes[-1]
t_years = 5 

r_equivalent = ((v_end / v_start) ** (1 / t_years)) - 1
r_percentage = r_equivalent * 100

print(f"--- ΑΠΟΤΕΛΕΣΜΑΤΑ ΜΟΝΤΕΛΟΥ ---")
print(f"Ο φόρτος τάσης (βάση 2025) είναι: {int(v_start)} οχήματα/ώρα")
print(f"Ο προβλεπόμενος φόρτος για το 2030 είναι: {int(v_end)} οχήματα/ώρα")
print(f"Αυτό αντιστοιχεί σε έναν ισοδύναμο σταθερό ρυθμό ανατοκισμού: r = {r_percentage:.2f}% ανά έτος.")