import engine
def run_intersection_logic(movements_dict, lost_time=12):
    for mv in movements_dict.values():
        engine.get_saturation_flow(mv)

    y1e = movements_dict["Κ1 Ευθεία"].y
    y1a = movements_dict["Κ1 Αριστερά"].y
    y2  = movements_dict["Κ2 Ευθ+Δεξ"].y
    y3  = movements_dict["Κ3 Μικτή"].y

    path1 = y1e + y3
    path2 = y2 + y1a + y3

    if path1 > path2:
        y_cr = path1
        critical_label = f"Σενάριο 1 (K1_Eυθ + K3) -> {path1:.3f}"
    else:
        y_cr = path2
        critical_label = f"Σενάριο 2 (K2 + K1_Aρ + K3) -> {path2:.3f}"

    
    best_valid_d = float('inf')
    best_valid_results = None

    best_any_d = float('inf')
    best_any_results = None

    
    for cycle in range(45, 125, 5):
        x_cr = y_cr * (cycle / (cycle - lost_time))
        g_avail = cycle - lost_time
        
        if path1 > path2:
            gg_exact = y3 * (g_avail / y_cr)
            g_k1e_exact = y1e * (g_avail / y_cr)
            y_ab_sum = y2 + y1a
            if y_ab_sum > 0:
                ga_exact = g_k1e_exact * (y2 / y_ab_sum)
                gb_exact = g_k1e_exact * (y1a / y_ab_sum)
            else:
                ga_exact = g_k1e_exact
                gb_exact = 0
        else:
            ga_exact = y2 * (g_avail / y_cr)
            gb_exact = y1a * (g_avail / y_cr)
            gg_exact = y3 * (g_avail / y_cr)

        ga = max(2, int(round(ga_exact)))
        gb = max(2, int(round(gb_exact)))
        gg = max(2, int(g_avail - ga - gb))

        movement_results = {}
        move_map = [("Κ1 Αριστερά", gb), ("Κ1 Ευθεία", ga+gb), ("Κ2 Ευθ+Δεξ", ga), ("Κ3 Μικτή", gg)]
        
        for name, g_val in move_map:
            mv = movements_dict[name]
            d, los = engine.get_performance_metrics(mv.flow, mv.saturation_flow, g_val, cycle)
            movement_results[name] = {"v": mv.flow, "d": d, "los": los, "s": round(mv.saturation_flow), "y": mv.y, "g": g_val}

        v_k1_total = movement_results["Κ1 Αριστερά"]["v"] + movement_results["Κ1 Ευθεία"]["v"]
        d_k1_app = (movement_results["Κ1 Αριστερά"]["d"] * movement_results["Κ1 Αριστερά"]["v"] + 
                    movement_results["Κ1 Ευθεία"]["d"] * movement_results["Κ1 Ευθεία"]["v"]) / v_k1_total if v_k1_total > 0 else 0
        
        approach_results = [
            {"name": "Πρόσβαση Κ1", "d": d_k1_app, "los": engine.get_los_grade(d_k1_app)},
            {"name": "Πρόσβαση Κ2", "d": movement_results["Κ2 Ευθ+Δεξ"]["d"], "los": engine.get_los_grade(movement_results["Κ2 Ευθ+Δεξ"]["d"])},
            {"name": "Πρόσβαση Κ3", "d": movement_results["Κ3 Μικτή"]["d"], "los": engine.get_los_grade(movement_results["Κ3 Μικτή"]["d"])}
        ]

        total_v = sum(m["v"] for m in movement_results.values())
        total_dv = sum(m["d"] * m["v"] for m in movement_results.values())
        d_node = total_dv / total_v if total_v > 0 else 0
        node_los = engine.get_los_grade(d_node)

        
        if d_node < best_any_d:
            best_any_d = d_node
            best_any_results = [movement_results, approach_results, d_node, node_los, cycle, x_cr, critical_label]

        
        if x_cr <= 0.92 and d_node < best_valid_d:
            best_valid_d = d_node
            best_valid_results = [movement_results, approach_results, d_node, node_los, cycle, x_cr, critical_label]

    
    if best_valid_results is not None:
        
        return tuple(best_valid_results)
    else:
        
        if best_any_results is not None:
            best_any_results[6] += "  ΥΠΕΡΚΟΡΕΣΜΟΣ (X > 0.92)"
            return tuple(best_any_results)
        else: 
            
            return {}, [], 0, "F", 0, 0, critical_label

def run_fixed_signal_analysis(movements_dict, cycle, ga, gb, gg):
    # mellontiki ajiologhsh
    for mv in movements_dict.values():
        engine.get_saturation_flow(mv)

    movement_results = {}
    move_map = [("Κ1 Αριστερά", gb), ("Κ1 Ευθεία", ga+gb), ("Κ2 Ευθ+Δεξ", ga), ("Κ3 Μικτή", gg)]
    
    for name, g_val in move_map:
        mv = movements_dict[name]
        d, los = engine.get_performance_metrics(mv.flow, mv.saturation_flow, g_val, cycle)
        movement_results[name] = {"v": mv.flow, "d": d, "los": los, "s": round(mv.saturation_flow), "y": mv.y, "g": g_val}

    v_k1_total = movement_results["Κ1 Αριστερά"]["v"] + movement_results["Κ1 Ευθεία"]["v"]
    d_k1_app = (movement_results["Κ1 Αριστερά"]["d"] * movement_results["Κ1 Αριστερά"]["v"] + 
                movement_results["Κ1 Ευθεία"]["d"] * movement_results["Κ1 Ευθεία"]["v"]) / v_k1_total if v_k1_total > 0 else 0
    
    approach_results = [
        {"name": "Πρόσβαση Κ1", "d": d_k1_app, "los": engine.get_los_grade(d_k1_app)},
        {"name": "Πρόσβαση Κ2", "d": movement_results["Κ2 Ευθ+Δεξ"]["d"], "los": engine.get_los_grade(movement_results["Κ2 Ευθ+Δεξ"]["d"])},
        {"name": "Πρόσβαση Κ3", "d": movement_results["Κ3 Μικτή"]["d"], "los": engine.get_los_grade(movement_results["Κ3 Μικτή"]["d"])}
    ]

    total_v = sum(m["v"] for m in movement_results.values())
    total_dv = sum(m["d"] * m["v"] for m in movement_results.values())
    d_node = total_dv / total_v if total_v > 0 else 0
    node_los = engine.get_los_grade(d_node)

    return movement_results, approach_results, d_node, node_los